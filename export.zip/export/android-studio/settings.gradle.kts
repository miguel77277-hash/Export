// Proyecto externo (Android Studio) para LENY TV 1.55.
// Este archivo NO lo usa la compilación de PocketBuilder: está dentro de
// export/ solo como copia de referencia para reconstruir el proyecto fuera.

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "LenyTV"
include(":app")
